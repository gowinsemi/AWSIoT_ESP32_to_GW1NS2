This empty directory serves as destination for temporary files
created by some tests, in particular, the test_codecmaps_* tests.
